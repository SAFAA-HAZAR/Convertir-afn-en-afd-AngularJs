                 Remise du projet:Algorithme de transformation d'un afn en afd et 
           d'une expression reguliaire en afn en utlisant la technologie d'Angular JS1
 

 ----------------------------------Groupe du projet:------------------------------------
                                   
                                     1-Sara Kididane
                                     2-Safaa Hazar
                                     3-Maryam Et-tolba
                      Filiere:Genie informatique-4eme annee-ENSAK
---------------------------------------------------------------------------------------
Ce projet utilise la biblioth�que GOJS :https://gojs.net/latest/index.html
Le projet comprend deux parties : 1- convertir afn en afd 
                                  2- convertir une expression reguliere en afn
---------------------------------------------------------------------------------------
                         Execution du projet:
 -->Veuillez lancer la page "home.html" 
 -->choisir le mode de conversion 
--------------------------------------------------------------------------------------- 
